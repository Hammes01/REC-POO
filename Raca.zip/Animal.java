public interface Animal {

    public String Tipo();
    public String getId();
}


public interface Terrestres {

    public String QuatroPatas();
    public String Dieta();
}