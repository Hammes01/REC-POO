public class Raca implements Animal,Terrestres {

    @Override
    public String getId() {

    }

    @Override
    public String getTipo() {

    }

    @Override
    public String getDieta() {

    }

    @Override
    public String getQuatroPatas() {

    }

}