public class Tecnico {
 
  private String nome;
  private float salario;
  
}