public class Time {
 
  private String nome;
  private Date fundacao;
  
   private Tecnico tecnico;
}