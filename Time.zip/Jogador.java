public class Jogador {
 
  private String nome;
  private String posicao;
  private int quantidadedeGols;
  
}