private class User {

    private String PrimeiroNome;
    private String UltimoNome;

    public User(String primeiroNome, String ultimoNome) {
        this.PrimeiroNome = primeiroNome;
        this.UltimoNome = ultimoNome;
    }

    public void setPrimeiroNome(String primeiroNome) {
        this.PrimeiroNome = primeiroNome;
    }

    public void setUltimoNome(String ultimoNome) {
        this.UltimoNome = ultimoNome;
    }

    public String getUltimoNome() {
        return UltimoNome;
    }

    public String getPrimeiroNome() {
        return PrimeiroNome;
    }

    public String output(){
        return PrimeiroNome.toUpperCase() + " " + UltimoNome.toUpperCase();
    }

    public String output(boolean showUltimoNome){

        if(showUltimoNome){
            return output();
        }
        return PrimeiroNome;
    }
}