import java.util.ArrayList;
import java.util.Collections;
import java.util.List;






public class Main {

    public static void Main(String[] args) {
        User usuario = new User ("Gabriel", "Hames" );
        System.out.println(User.output());
        System.out.println(User.output(false));
    }
}

